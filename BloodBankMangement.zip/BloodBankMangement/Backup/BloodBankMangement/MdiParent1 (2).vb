Imports System.Windows.Forms

Public Class MdiParent1
    Private Sub BloodBankDetailsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CompDetailsForm.MdiParent = Me
        CompDetailsForm.Show()
    End Sub

    Private Sub DonorDetailsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DonorDetailsToolStripMenuItem.Click
        DonorDetForm.MdiParent = Me
        DonorDetForm.Show()
    End Sub

    Private Sub EquipmentDetailsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles EquipmentDetailsToolStripMenuItem.Click
        EquipmentForm.MdiParent = Me
        EquipmentForm.Show()
    End Sub

    Private Sub ReceipToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ReceipToolStripMenuItem.Click
        CustForm.MdiParent = Me
        CustForm.Show()


    End Sub

    Private Sub CampScheduleToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CampScheduleToolStripMenuItem.Click
        CampScheduleForm.MdiParent = Me
        CampScheduleForm.Show()
    End Sub

    Private Sub BloodCollectionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BloodCollectionToolStripMenuItem.Click
        CollectionForm.MdiParent = Me
        CollectionForm.Show()
    End Sub

    Private Sub IssueToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IssueToolStripMenuItem.Click
        IssueForm.MdiParent = Me
        IssueForm.Show()

    End Sub

    Private Sub StockReportToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles StockReportToolStripMenuItem.Click
        StockRepForm.MdiParent = Me
        StockRepForm.Show()

    End Sub

    Private Sub ExperyDaysOldToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ExperyDaysOldToolStripMenuItem.Click
        ExperyDetRepForm.MdiParent = Me
        ExperyDetRepForm.Show()
    End Sub

    Private Sub CollectionReportToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CollectionReportToolStripMenuItem.Click

        CollectionRepForm.MdiParent = Me
        CollectionRepForm.Show()
    End Sub

    Private Sub IssueReportToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles IssueReportToolStripMenuItem.Click
        IssueRepForm.MdiParent = Me
        IssueRepForm.Show()

    End Sub



    Private Sub DonToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DonToolStripMenuItem.Click
        DonorRepForm.MdiParent = Me
        DonorRepForm.Show()
    End Sub




    Private Sub RImdi_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        End
    End Sub

    Private Sub InfoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InfoToolStripMenuItem.Click
        Dis1.MdiParent = Me
        Dis1.Show()
    End Sub
End Class
