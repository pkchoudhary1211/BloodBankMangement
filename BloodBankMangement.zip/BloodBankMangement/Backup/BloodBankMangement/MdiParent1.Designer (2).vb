<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MdiParent1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.MasterEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DonorDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReceipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EquipmentDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CampScheduleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BloodCollectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StockReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.IssueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExperyDaysOldToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CollectionReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.IssueReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterEntryToolStripMenuItem, Me.CampScheduleToolStripMenuItem, Me.BloodCollectionToolStripMenuItem, Me.StockReportToolStripMenuItem, Me.IssueToolStripMenuItem, Me.ReportToolStripMenuItem, Me.InfoToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1185, 26)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MasterEntryToolStripMenuItem
        '
        Me.MasterEntryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DonorDetailsToolStripMenuItem, Me.ReceipToolStripMenuItem, Me.EquipmentDetailsToolStripMenuItem})
        Me.MasterEntryToolStripMenuItem.Name = "MasterEntryToolStripMenuItem"
        Me.MasterEntryToolStripMenuItem.Size = New System.Drawing.Size(104, 22)
        Me.MasterEntryToolStripMenuItem.Text = "Master Entry"
        '
        'DonorDetailsToolStripMenuItem
        '
        Me.DonorDetailsToolStripMenuItem.Name = "DonorDetailsToolStripMenuItem"
        Me.DonorDetailsToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.DonorDetailsToolStripMenuItem.Text = "Donor Details"
        '
        'ReceipToolStripMenuItem
        '
        Me.ReceipToolStripMenuItem.Name = "ReceipToolStripMenuItem"
        Me.ReceipToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.ReceipToolStripMenuItem.Text = "Recipient Details"
        '
        'EquipmentDetailsToolStripMenuItem
        '
        Me.EquipmentDetailsToolStripMenuItem.Name = "EquipmentDetailsToolStripMenuItem"
        Me.EquipmentDetailsToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.EquipmentDetailsToolStripMenuItem.Text = "Equipment Details"
        '
        'CampScheduleToolStripMenuItem
        '
        Me.CampScheduleToolStripMenuItem.Name = "CampScheduleToolStripMenuItem"
        Me.CampScheduleToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.CampScheduleToolStripMenuItem.Text = "Camp Schedule"
        '
        'BloodCollectionToolStripMenuItem
        '
        Me.BloodCollectionToolStripMenuItem.Name = "BloodCollectionToolStripMenuItem"
        Me.BloodCollectionToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.BloodCollectionToolStripMenuItem.Text = "Blood Collection"
        '
        'StockReportToolStripMenuItem
        '
        Me.StockReportToolStripMenuItem.Name = "StockReportToolStripMenuItem"
        Me.StockReportToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.StockReportToolStripMenuItem.Text = "Stock Report"
        '
        'IssueToolStripMenuItem
        '
        Me.IssueToolStripMenuItem.Name = "IssueToolStripMenuItem"
        Me.IssueToolStripMenuItem.Size = New System.Drawing.Size(56, 22)
        Me.IssueToolStripMenuItem.Text = "Issue"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExperyDaysOldToolStripMenuItem, Me.CollectionReportToolStripMenuItem, Me.IssueReportToolStripMenuItem, Me.DonToolStripMenuItem})
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(63, 22)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'ExperyDaysOldToolStripMenuItem
        '
        Me.ExperyDaysOldToolStripMenuItem.Name = "ExperyDaysOldToolStripMenuItem"
        Me.ExperyDaysOldToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.ExperyDaysOldToolStripMenuItem.Text = "Expery / Days old "
        '
        'CollectionReportToolStripMenuItem
        '
        Me.CollectionReportToolStripMenuItem.Name = "CollectionReportToolStripMenuItem"
        Me.CollectionReportToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.CollectionReportToolStripMenuItem.Text = "Collection Report"
        '
        'IssueReportToolStripMenuItem
        '
        Me.IssueReportToolStripMenuItem.Name = "IssueReportToolStripMenuItem"
        Me.IssueReportToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.IssueReportToolStripMenuItem.Text = "Issue Report"
        '
        'DonToolStripMenuItem
        '
        Me.DonToolStripMenuItem.Name = "DonToolStripMenuItem"
        Me.DonToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.DonToolStripMenuItem.Text = "Donor Report"
        '
        'InfoToolStripMenuItem
        '
        Me.InfoToolStripMenuItem.Name = "InfoToolStripMenuItem"
        Me.InfoToolStripMenuItem.Size = New System.Drawing.Size(47, 22)
        Me.InfoToolStripMenuItem.Text = "Info"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 596)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1185, 22)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 26)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1185, 25)
        Me.ToolStrip1.TabIndex = 3
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'MdiParent1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1185, 618)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MdiParent1"
        Me.Text = "Abee Blood Bank Management Software"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MasterEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents DonorDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReceipToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EquipmentDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CampScheduleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BloodCollectionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IssueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExperyDaysOldToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CollectionReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IssueReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
