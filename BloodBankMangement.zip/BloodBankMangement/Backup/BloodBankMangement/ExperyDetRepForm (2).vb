Imports System.Data.SqlClient
Public Class ExperyDetRepForm
    Dim pkVar As Long
    Private Sub ExperyDetRepForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.WindowState = FormWindowState.Maximized


    End Sub


    Private Sub butClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butClose.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim date1 As Date
        Dim D1, M1, Y1 As Integer
        D1 = Today.Day
        M1 = Today.Month
        Y1 = Today.Year
        If M1 = 1 Then
            M1 = 12
            Y1 = Y1 - 1
        Else
            M1 = M1 - 1
        End If
        q1Var = M1 & "/" & D1 & "/" & Y1
        date1 = Convert.ToDateTime(q1Var)
        q1Var = "Select bloodGroup ,PackNo, vDate From CollectionTab where ivNo=0  and vdate <= '" & Format(date1, "dd-MMM-yyyy") & "' order by BloodGroup,vNo"
        MsgBox(q1Var)
        If Conn.State = ConnectionState.Open Then Conn.Close()
        Conn.Open()
        Dim DS1 As New DataSet
        Dim adp As New SqlDataAdapter(q1Var, Conn)
        adp.Fill(DS1)
        DG1.DataSource = DS1.Tables(0)
        If Conn.State = ConnectionState.Open Then Conn.Close()
    End Sub

    Private Sub butList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butList.Click
        If Conn.State = ConnectionState.Open Then Conn.Close()
        Conn.Open()
        Dim DS1 As New DataSet
        Dim adp As New SqlDataAdapter("Select bloodGroup ,PackNo, vDate From CollectionTab where ivNo=0   order by BloodGroup,vNo", Conn)
        adp.Fill(DS1)
        DG1.DataSource = DS1.Tables(0)
        If Conn.State = ConnectionState.Open Then Conn.Close()
    End Sub

    Private Sub DG1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DG1.CellContentClick

    End Sub
End Class
