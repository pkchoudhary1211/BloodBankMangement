Public Class Dis1

    Private Sub Dis1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class